<?php
// Heading 
$_['heading_title']     = 'News';

// Text
$_['text_title']		= 'Title';
$_['text_description']	= 'Description';
$_['text_date']			= 'Date Added';
$_['text_action']		= 'Action';
$_['text_status']		= 'Status';
$_['text_keyword']		= 'SEO Keyword';

// Success
$_['text_success']		= 'You have successfully modified news!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify news!';
?>