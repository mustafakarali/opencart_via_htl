<?php
// Heading
$_['heading_title']      = '免费结帐';

// Text
$_['text_payment']       = '支付管理';
$_['text_success']       = '成功：您已修改的免费结帐信息！';

// Entry
$_['entry_order_status'] = '订单状态：';
$_['entry_status']       = '状态：';
$_['entry_sort_order']   = '排序：';

// Error
$_['error_permission']   = '警告： 您没有权限修改免费结账支付！';
?>