<?php
// Text
$_['text_footer'] = '<a href="http://www.opencartchina.com">OpenCart China</a> &copy; 2013-' . date('Y') . ' All Rights Reserved.<br />Version %s';
?>