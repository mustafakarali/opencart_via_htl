<?php
// Heading
$_['heading_title'] = '错误日志';

// Text
$_['text_success']  = '成功：您已成功清除错误日志！';
?>