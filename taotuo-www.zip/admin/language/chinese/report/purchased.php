<?php

// Heading
$_['heading_title']   = '商品购买报表';

// Column
$_['column_name']     = '商品名称';
$_['column_model']    = '商品型号';
$_['column_quantity'] = '购买数量';
$_['column_total']    = '金额总计';
?>
