<?php
// Heading
$_['heading_title']    = '总计';

// Text
$_['text_total']       = '订单总计';
$_['text_success']     = '成功： 您已成功修改订单总计！';

// Entry
$_['entry_status']     = '状态：';
$_['entry_sort_order'] = '排序：';

// Error
$_['error_permission'] = '警告： 您没有变更总计的权限！';
?>
