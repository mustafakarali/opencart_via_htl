<?php
// HTTP
define('HTTP_SERVER', 'http://jalen.opencart/');

// HTTPS
define('HTTPS_SERVER', 'http://jalen.opencart/');

// DIR
define('DIR_APPLICATION', 'E:\WWW\opencart_v1.5.5.1_cn/catalog/');
define('DIR_SYSTEM', 'E:\WWW\opencart_v1.5.5.1_cn/system/');
define('DIR_DATABASE', 'E:\WWW\opencart_v1.5.5.1_cn/system/database/');
define('DIR_LANGUAGE', 'E:\WWW\opencart_v1.5.5.1_cn/catalog/language/');
define('DIR_TEMPLATE', 'E:\WWW\opencart_v1.5.5.1_cn/catalog/view/theme/');
define('DIR_CONFIG', 'E:\WWW\opencart_v1.5.5.1_cn/system/config/');
define('DIR_IMAGE', 'E:\WWW\opencart_v1.5.5.1_cn/image/');
define('DIR_CACHE', 'E:\WWW\opencart_v1.5.5.1_cn/system/cache/');
define('DIR_DOWNLOAD', 'E:\WWW\opencart_v1.5.5.1_cn/download/');
define('DIR_LOGS', 'E:\WWW\opencart_v1.5.5.1_cn/system/logs/');

// DB
define('DB_DRIVER', 'mysql');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');
define('DB_DATABASE', 'opencart');
define('DB_PREFIX', 'oc_');
?>