=====================================
See website for OpenCart Install information
http://code.google.com/p/vqmod/wiki/Install_OpenCart
=====================================